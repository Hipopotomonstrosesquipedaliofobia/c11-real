var seaimg;
var ship;
var sea;
var seaImg, shipImg;

function preload(){
seaImg = loadImage("sea.png");
shipImg = loadAnimation("ship-1.png","ship-2.png" , "ship-4.png");
}

function setup(){
  createCanvas(400,400);
 sea =  createSprite(400,200);
 sea.addImage(seaImg)
 
 sea.scale = 0.8;
 ship =  createSprite(130,200);
 ship.scale= 0.4;
 ship.addAnimation("barco",shipImg)
}

function draw() {
  background("blue");
drawSprites();
 
}